//
//  GameLocal.swift
//  ARKitHorizontalPlaneDemo
//
//  Created by Karthik on 11/30/18.
//  Copyright © 2018 eye_Ohh_ess. All rights reserved.
//

import Foundation
import UIKit
import ARKit
import MultipeerConnectivity


class GameLocal {
    
//    @IBOutlet weak var sceneView: ARSCNView!
    
    var cube: Cube!
    var availablePositions: [String] = []

    var sessionInfoView: UIView!
    var sessionInfoLabel: UILabel!
    var sceneView: ARSCNView!
    var sendMapButton: UIButton!
    var mappingStatusLabel: UILabel!
    
    var multipeerSession: MultipeerSession!
    var mapProvider: MCPeerID?
    
    var prevLocation = CGPoint(x: 0, y: 0)
    var cubePlaced: Bool = false
    
    init(sessionInfoView: UIView, sessionInfoLabel: UILabel, sceneView: ARSCNView, sendMapButton: UIButton, mappingStatusLabel: UILabel) {
        
        self.sessionInfoView = sessionInfoView
        self.sessionInfoLabel = sessionInfoLabel
        self.sceneView = sceneView
        self.sendMapButton = sendMapButton
        self.mappingStatusLabel = mappingStatusLabel
        
        self.cube = Cube(sceneView: sceneView)
        multipeerSession = MultipeerSession(receivedDataHandler: receivedData)
        createAvailablePositions()
    }
    
    func stopPlaneDetection() {
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = []               // this tells sceneView to detect horizontal planes
        sceneView.debugOptions = []
        sceneView.session.run(configuration)
    }
    
    private func createAvailablePositions(){
        for i in 0...2 {
            for j in 0...2 {
                for k in 0...2 {
                    self.availablePositions.append(String(i) + String(j) + String(k))
                }
            }
        }
    }
    
    func rePlace() {
        sceneView.scene.rootNode.enumerateChildNodes { (node, stop) in
            node.removeFromParentNode()
        }
        
        cubePlaced = false
    }
    
    func userTap(withGestureRecognizer recognizer: UIGestureRecognizer) {
        let tapLocation: CGPoint = recognizer.location(in: sceneView)
        let isTapComplete = recognizer.state == UIGestureRecognizer.State.ended
        
        if !cubePlaced {
            handleCubePlacement(tapLocation: tapLocation, isTapComplete: isTapComplete)
        }
        else {
            handleGameMove(tapLocation: tapLocation, isTapComplete: isTapComplete)
        }
    }
    
    private func handleCubePlacement(tapLocation: CGPoint, isTapComplete: Bool) {
        cube.removeLastPreviewCube()
        
        guard let hitTestResult = sceneView
            .hitTest(tapLocation, types: [.existingPlaneUsingGeometry, .estimatedHorizontalPlane])
            .first
            else { return }
        
        let translation: float3 = hitTestResult.worldTransform.translation
        
        if (isTapComplete) {                // when tap is release we want to place the cube
            rePlace()                       // remove plane

            // Place an anchor for a virtual character. The model appears in renderer(_:didAdd:for:).
            let anchor = ARAnchor(name: "panda", transform: hitTestResult.worldTransform)
            sceneView.session.add(anchor: anchor)
            cube.placeCube(translation: translation)
            cubePlaced = true
            stopPlaneDetection()
            
            // Send the anchor info to peers, so they can place the same content.
            guard let data = try? NSKeyedArchiver.archivedData(withRootObject: anchor, requiringSecureCoding: true)
                else { fatalError("can't encode anchor") }
            self.multipeerSession.sendToAllPeers(data)
        }
        else if prevLocation != tapLocation {
            prevLocation = tapLocation      // set current tap location to prev
            cube.previewCube(translation: translation)
        }
    }
    
    private func handleGameMove(tapLocation: CGPoint, isTapComplete: Bool) {
        let hitTestResults = sceneView.hitTest(tapLocation, options: nil)
        
        guard let tappedNode = hitTestResults.first?.node else { return }
        var cell = Cell()
        
        print("HI")
        guard let cellNode: Cell = tappedNode as? Cell else { return }
        

        print(cellNode.index)
        
        guard let nodeName = tappedNode.name else { return }
        
        if (isTapComplete) && availablePositions.contains(nodeName) {    // when tap is release we want to place the cells
            
            let userMove = cube.placeCell(tappedCell: cellNode, isUser: true)
//            removeValidMove(cellIndex: userMove)
            
            //                let aiMove = ai.getMove(availablePositions: availablePositions)
            let aiMove = availablePositions.randomElement()!
            removeValidMove(cellIndex: aiMove)
            
//            print("User played" + userMove)s
            print("AI played" + aiMove)
            
            sceneView.scene.rootNode.enumerateChildNodes { (nodeToReplace, stop) in
                if nodeToReplace.name == aiMove {
                    cube.placeCell(tappedCell: cellNode, isUser: false)
                }
            }
            
        }
            
        else if availablePositions.contains(nodeName) {
            cube.previewCell(node: tappedNode)
        }
    }
    
    private func removeValidMove(cellIndex: String) {
        let idx = availablePositions.firstIndex(of: cellIndex)
        availablePositions.remove(at: idx!)
    }
    
    
    
    
    
    
    /// - Tag: CheckMappingStatus
    func session(_ session: ARSession, didUpdate frame: ARFrame) {
        switch frame.worldMappingStatus {
        case .notAvailable, .limited:
            sendMapButton.isEnabled = false
        case .extending:
            sendMapButton.isEnabled = !multipeerSession.connectedPeers.isEmpty
        case .mapped:
            sendMapButton.isEnabled = !multipeerSession.connectedPeers.isEmpty
        }
        mappingStatusLabel.text = frame.worldMappingStatus.description
        updateSessionInfoLabel(for: frame, trackingState: frame.camera.trackingState)
    }
    
    /// - Tag: GetWorldMap
    func shareSession() {
        sceneView.session.getCurrentWorldMap { worldMap, error in
            guard let map = worldMap
                else { print("Error: \(error!.localizedDescription)"); return }
            guard let data = try? NSKeyedArchiver.archivedData(withRootObject: map, requiringSecureCoding: true)
                else { fatalError("can't encode map") }
            self.multipeerSession.sendToAllPeers(data)
        }
    }

    /// - Tag: ReceiveData
    func receivedData(_ data: Data, from peer: MCPeerID) {
        
        do {
            if let worldMap = try NSKeyedUnarchiver.unarchivedObject(ofClass: ARWorldMap.self, from: data) {
                // Run the session with the received world map.
                let configuration = ARWorldTrackingConfiguration()
                configuration.planeDetection = .horizontal
                configuration.initialWorldMap = worldMap
                sceneView.session.run(configuration, options: [.resetTracking, .removeExistingAnchors])
                
                // Remember who provided the map for showing UI feedback.
                mapProvider = peer
            }
            else
                if let anchor = try NSKeyedUnarchiver.unarchivedObject(ofClass: ARAnchor.self, from: data) {
                    // Add anchor to the session, ARSCNView delegate adds visible content.
                    sceneView.session.add(anchor: anchor)
                }
                else {
                    print("unknown data recieved from \(peer)")
            }
        } catch {
            print("can't decode data recieved from \(peer)")
        }
    }
    
    // MARK: - AR session management
    func updateSessionInfoLabel(for frame: ARFrame, trackingState: ARCamera.TrackingState) {
        // Update the UI to provide feedback on the state of the AR experience.
        let message: String
        
        switch trackingState {
        case .normal where frame.anchors.isEmpty && multipeerSession.connectedPeers.isEmpty:
            // No planes detected; provide instructions for this app's AR interactions.
            message = "Move around to map the environment, or wait to join a shared session."
            
        case .normal where !multipeerSession.connectedPeers.isEmpty && mapProvider == nil:
            let peerNames = multipeerSession.connectedPeers.map({ $0.displayName }).joined(separator: ", ")
            message = "Connected with \(peerNames)."
            
        case .notAvailable:
            message = "Tracking unavailable."
            
        case .limited(.excessiveMotion):
            message = "Tracking limited - Move the device more slowly."
            
        case .limited(.insufficientFeatures):
            message = "Tracking limited - Point the device at an area with visible surface detail, or improve lighting conditions."
            
        case .limited(.initializing) where mapProvider != nil,
             .limited(.relocalizing) where mapProvider != nil:
            message = "Received map from \(mapProvider!.displayName)."
            
        case .limited(.relocalizing):
            message = "Resuming session — move to where you were when the session was interrupted."
            
        case .limited(.initializing):
            message = "Initializing AR session."
            
        default:
            // No feedback needed when tracking is normal and planes are visible.
            // (Nor when in unreachable limited-tracking states.)
            message = ""
            
        }
        
        sessionInfoLabel.text = message
        sessionInfoView.isHidden = message.isEmpty
    }
    
}

extension SCNHitTestResult {
    
}
