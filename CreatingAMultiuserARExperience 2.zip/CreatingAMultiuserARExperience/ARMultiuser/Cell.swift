//
//  cell.swift
//  ARKitHorizontalPlaneDemo
//
//  Created by Karthik on 10/28/18.
//  Copyright © 2018 eye_Ohh_ess. All rights reserved.
//

import Foundation
import UIKit
import ARKit

class Cell: SCNNode {
    
    enum cellState {
        case sphere
        case cross
        case empty
    }
    
    struct Index {
        var i, j, k: Int?      // stores the location of the cell
    }
    
    var index = Index()
    var state: cellState?  // is reset for generator and solver
    
    // MARK: - Initialization
    override init() {
        super.init()
        
        // Set initial game board scale
//        simdScale = float3(GameBoard.minimumScale)
        
//        addChildNode(borderNode)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("\(#function) has not been implemented")
    }
    
    func setData(i: Int, j: Int, k:Int, state: cellState) {
        // set cell index
        self.index.i = i
        self.index.j = j
        self.index.k = k
        
        self.setCellState(state: state)
        self.name = String(i) + String(j) + String(k)
    }
    

    
    func setCellState(state: cellState) {
        var stateName: String!
        if (state == cellState.empty) {
            stateName = "Cell-Empty"
        }
        else if (state == cellState.cross) {
            stateName = "Cell-Cross"
        }
        else if (state == cellState.sphere){
            stateName = "Cell-Sphere"
        }
        else { fatalError() }
        
        self.state = state          // set stare to empty, cross or sphere
        
        guard let gameScene = SCNScene(named: "Assets.scnassets/game.scn") else { fatalError() }
        guard let node = gameScene.rootNode.childNode(withName: stateName, recursively: false)
            else { fatalError() }
        
        
        addChildNode(node)
    }
    
    func setPosition(pos: SCNVector3) {
        self.position = pos
    }
    
    func removeXO(cubeIndex: String, type: String) {
        // removes the 'X' or 'O' 3D object so it is a empty cell
    }
}
