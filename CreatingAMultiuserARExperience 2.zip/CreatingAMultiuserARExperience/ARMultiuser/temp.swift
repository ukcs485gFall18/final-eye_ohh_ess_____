//
//  temp.swift
//  ARMultiuser
//
//  Created by Karthik on 12/9/18.
//  Copyright © 2018 Apple. All rights reserved.
//

import Foundation
import SceneKit

extension SCNHitTestResult {
    
    
    /*! The hit node. */
    open var node: Cell { get }


}
